/*!@license
* Infragistics.Web.ClientUI Toolbar localization resources 17.2.66
*
* Copyright (c) 2011-2017 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.Toolbar=$.ig.Toolbar||{};$.ig.locale=$.ig.locale||{};$.ig.locale.en=$.ig.locale.en||{};$.ig.locale.en.Toolbar={collapseButtonTitle:"Collapse {0}",expandButtonTitle:"Expand {0}"};$.ig.Toolbar.locale=$.ig.Toolbar.locale||$.ig.locale.en.Toolbar;return $.ig.locale.en.Toolbar});