/*!@license
* Infragistics.Web.ClientUI Scroll localization resources 17.2.66
*
* Copyright (c) 2011-2017 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.Scroll=$.ig.Scroll||{};$.ig.locale=$.ig.locale||{};$.ig.locale.es=$.ig.locale.es||{};$.ig.locale.es.Scroll={errorNoElementLink:"El elemento que se está vinculando no existe.",errorNoScrollbarLink:"El elemento de la barra de desplazamiento que se está vinculando no existe."};$.ig.Scroll.locale=$.ig.Scroll.locale||$.ig.locale.es.Scroll;return $.ig.locale.es.Scroll});