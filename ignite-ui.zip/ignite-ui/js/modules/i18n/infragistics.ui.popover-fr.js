/*!@license
* Infragistics.Web.ClientUI Popover localization resources 17.2.66
*
* Copyright (c) 2011-2017 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.fr=$.ig.locale.fr||{};$.ig.Popover=$.ig.Popover||{};$.ig.locale.fr.Popover={popoverOptionChangeNotSupported:"La modification de l'option suivante après l'initialisation de FinPopig n'est pas prise en charge :",popoverShowMethodWithoutTarget:"Le paramètre target de la fonction show est obligatoire lorsque l'option selectors est utilisée"};$.ig.Popover.locale=$.ig.Popover.locale||$.ig.locale.fr.Popover;return $.ig.locale.fr.Popover});