/*!@license
* Infragistics.Web.ClientUI Scroll localization resources 17.2.66
*
* Copyright (c) 2011-2017 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.Scroll=$.ig.Scroll||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ru=$.ig.locale.ru||{};$.ig.locale.ru.Scroll={errorNoElementLink:"Связанный элемент не найден.",errorNoScrollbarLink:'Связанный элемент "полоса прокрутки" не найден.'};$.ig.Scroll.locale=$.ig.Scroll.locale||$.ig.locale.ru.Scroll;return $.ig.locale.ru.Scroll});