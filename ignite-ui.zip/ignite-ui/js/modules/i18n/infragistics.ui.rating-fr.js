/*!@license
* Infragistics.Web.ClientUI Rating localization resources 17.2.66
*
* Copyright (c) 2011-2017 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.Rating=$.ig.Rating||{};$.ig.locale=$.ig.locale||{};$.ig.locale.fr=$.ig.locale.fr||{};$.ig.locale.fr.Rating={setOptionError:"Les modifications de temps d'exécution ne sont pas autorisées pour l'option suivante : "};$.ig.Rating.locale=$.ig.Rating.locale||$.ig.locale.fr.Rating;return $.ig.locale.fr.Rating});