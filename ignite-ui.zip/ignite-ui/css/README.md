==== structure ====
- in this folder you can find all styles related to ignite UI components structure (widths,heights,margins,paddings.etc).
The files in that folder are very important, otherwise ignite UI controls will NOT work correctly.

NOTE: The structure files are NOT related to any theme!

===== themes =====
- This is the folder that contain all the themes for ignite UI and jQuery UI components.

1. Bootstrap 3 - Themes compatible with bootstrap 3
2. Bootstrap 4 - Themes compatible with bootstrap 4
3. infragistics
3. infragistics2012
3. IOS
3. Metro


